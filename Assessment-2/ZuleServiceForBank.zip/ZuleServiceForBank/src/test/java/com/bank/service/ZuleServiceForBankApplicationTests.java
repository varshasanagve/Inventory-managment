package com.bank.service;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuleServiceForBankApplicationTests {

	//@Test
	void contextLoads() {
	}

}
