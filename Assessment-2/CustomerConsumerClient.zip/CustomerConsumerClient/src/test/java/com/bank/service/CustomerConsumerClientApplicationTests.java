package com.bank.service;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerConsumerClientApplicationTests {

	//@Test
	void contextLoads() {
	}

}
