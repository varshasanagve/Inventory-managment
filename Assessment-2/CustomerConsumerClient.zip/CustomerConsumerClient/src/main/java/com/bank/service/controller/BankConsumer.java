package com.bank.service.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.bank.service.dao.BankDaoJpa;
import com.bank.service.model.customer;


@RestController
public class BankConsumer {
	
	@Autowired
	private BankDaoJpa bankDaoJpa;

	
	@RequestMapping(value = "/getAllCustomerDetails", method = RequestMethod.GET)
	  public List<customer> getAllProducts(){
		  
			 return bankDaoJpa.findAll();
		}
	
	
	  
}
