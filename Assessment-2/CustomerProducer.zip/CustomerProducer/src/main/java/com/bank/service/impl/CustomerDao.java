package com.bank.service.impl;

import com.bank.service.model.customer;


public interface CustomerDao {

	String getAllAccounts();

	customer createAccount(customer customer);

	customer updateAccountById(int accountid, String name);

	String deleteAccount(int accountId);

}
