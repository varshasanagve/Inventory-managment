package com.bank.service.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank.service.impl.CustomerDao;
import com.bank.service.model.customer;


@RestController
@RequestMapping("/bank")
public class CustomerController {
	
	private static Logger LOGGER = LoggerFactory.getLogger(CustomerController.class);
	
	@Autowired
	private CustomerDao customerDao;
	
	 @GetMapping("/getAllAccounts")
	    public String getAllAccounts(){
		 LOGGER.info("In getAllAccounts "+customerDao.getAllAccounts());
	        return customerDao.getAllAccounts();
	       
	    }
	 
	 @PostMapping("/createAccount")
	    public customer createAccount(@RequestBody customer customer){
		 LOGGER.info("In createAccount "+customerDao.createAccount(customer));
	        return customerDao.createAccount(customer);
	    }
	 
	 @PutMapping("/updateAccountbyId/{accountid}/{name}")
	    public customer updateAccountById(@PathVariable int accountid,@PathVariable String name){
		 LOGGER.info("In updateAccountById "+accountid +"name" +name);
	        return customerDao.updateAccountById(accountid, name);
	    }
	 
	 @DeleteMapping("/deleteAccountById/{accountid}")
	    public String deleteTicketById(@PathVariable int accountid){
		 LOGGER.info("In @DeleteMapping ");
	        return customerDao.deleteAccount(accountid);
	    }
	 
	 
}
